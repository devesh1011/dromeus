"""Trainer interface."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

import numpy as np


class WeightTrainer(Protocol):
    """Owns model, optimizer, and local training state."""

    def train_local_steps(self, step_count: int) -> None: ...

    def weights(self) -> dict[str, np.ndarray]:
        """Return a copy of current model weights."""
        ...

    def load_weights(self, weights: dict[str, np.ndarray]) -> None:
        """Replace current model weights."""
        ...

    @property
    def local_loss(self) -> float | None:
        """Return the latest local loss, or none before training."""
        ...

    def evaluate(self) -> tuple[float, float] | None:
        """Return local evaluation loss and accuracy, or none when unavailable."""
        ...


@runtime_checkable
class CheckpointTrainer(WeightTrainer, Protocol):
    """Trainer whose complete durable state is tensor-serializable."""

    def checkpoint_tensors(self) -> dict[str, np.ndarray]: ...

    def load_checkpoint_tensors(self, state: dict[str, np.ndarray]) -> None: ...
