"""Local model training."""
