"""Node runtime lifecycle."""

from __future__ import annotations

import asyncio
import inspect
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING, Protocol

import numpy as np

from dromeus.algorithms.codec import (
    BitmapTopKInt8Codec,
    DenseInt8Codec,
    IdentityCodec,
    TopKInt8Codec,
)
from dromeus.algorithms.dpsgd import DPSGDAdapter
from dromeus.algorithms.noloco import NoLoCoAlgorithm
from dromeus.gossip.axl import (
    AXLFailureBroadcaster,
    AXLPairTransport,
    decode_run_failure,
)
from dromeus.gossip.engine import GossipEngine
from dromeus.gossip.interfaces import (
    GossipAlgorithm,
    RoundCommit,
    RunFailure,
)
from dromeus.gossip.peer_scheduler import PeerScheduler
from dromeus.manifests.canonical import validate_sealed_expectation
from dromeus.manifests.models import (
    DPSGD_ALGORITHM_ID,
    NOLOCO_ALGORITHM_ID,
    ConsensusSketchMessage,
    DataContract,
    DraftRunSpec,
    EnvironmentFingerprint,
    Invitation,
    SealedManifest,
    SealedManifestExpectation,
    TensorSchema,
)
from dromeus.membership.formation import FormationProtocol, FormationResult
from dromeus.persistence.run_store import RunStore
from dromeus.protocol.models import MessageType
from dromeus.telemetry.consensus import (
    ConsensusDistance,
    LiveConsensusTelemetry,
)
from dromeus.telemetry.events import EventSink, emit_event
from dromeus.telemetry.evidence import (
    ConsensusDistanceEvidence,
    ConsensusSketchSentEvidence,
    RunFailedEvidence,
    append_evidence,
)
from dromeus.telemetry.metrics import MetricsPublisher
from dromeus.training.base import WeightTrainer
from dromeus.training.cifar10 import (
    PreparedCIFAR10Training as TrainingOwnedCIFAR,
)
from dromeus.training.cifar10 import prepare_training
from dromeus.training.local import (
    PreparedLocalTraining as TrainingOwnedLocal,
)
from dromeus.training.local import (
    prepare_local_training as prepare_training_local,
)
from dromeus.training.local_data import LocalClassificationData, load_local_data
from dromeus.training.models import resolve_model
from dromeus.training.trainer import InitialCheckpoint
from dromeus.transport.interface import AsyncTransport
from dromeus.transport.receiver import MessageChannel

if TYPE_CHECKING:
    from torch import nn


class NodeRuntimeError(RuntimeError):
    """The node runtime lifecycle was used out of order."""


class PeerRunFailureError(RuntimeError):
    """A sealed peer announced terminal run failure."""


class NodeState(StrEnum):
    CREATED = "created"
    FORMING = "forming"
    READY = "ready"
    RUNNING = "running"
    COMPLETE = "complete"
    FAILED = "failed"
    STOPPED = "stopped"


class MetricsService(MetricsPublisher, Protocol):
    """Metrics publisher with an optional runtime-owned task lifecycle."""

    async def start(self) -> None: ...

    async def stop(self) -> None: ...


@dataclass(frozen=True, slots=True)
class TrainingConfig:
    """Dependencies needed to run the formed node's local training."""

    algorithm: GossipAlgorithm
    load_checkpoint: Callable[[Path], None]
    run_store: RunStore
    artifact_root: Path
    metrics_publisher: MetricsService | None = None
    evaluation_interval: int = 5

    def __post_init__(self) -> None:
        if self.evaluation_interval <= 0:
            raise ValueError("evaluation interval must be positive")


@dataclass(frozen=True, slots=True)
class FailureConfig:
    """Durable dependencies available immediately after formation."""

    run_store: RunStore
    artifact_root: Path

    @classmethod
    def for_run_root(cls, run_root: Path) -> FailureConfig:
        return cls(
            run_store=RunStore(run_root / "run-store"),
            artifact_root=run_root / "rounds",
        )


@dataclass(frozen=True, slots=True)
class InitiatorFormation:
    """Immutable inputs for initiator formation."""

    bootstrap_uri: str
    checkpoint_path: Path
    tensor_schema: TensorSchema


@dataclass(frozen=True, slots=True)
class ParticipantFormation:
    """Immutable inputs for participant formation."""

    invitation: Invitation


type FormationRequest = InitiatorFormation | ParticipantFormation


@dataclass(frozen=True, slots=True)
class NodeRunResult:
    """Immutable terminal result from one complete node lifecycle."""

    formation: FormationResult
    commits: tuple[RoundCommit, ...]


type TrainingFactory = Callable[[FormationResult], TrainingConfig]
type ReadyHook = Callable[[FormationResult], None | Awaitable[None]]
type CompletionHook = Callable[[NodeRunResult], None | Awaitable[None]]


@dataclass(frozen=True, slots=True)
class PreparedCIFARTraining:
    """Runtime composition over the deep training-owned CIFAR interface."""

    _training: TrainingOwnedCIFAR

    def create_initial_checkpoint(self, path: Path) -> InitialCheckpoint:
        return self._training.create_initial_checkpoint(path)

    def build_config(
        self,
        *,
        result: FormationResult,
        local_public_key: str,
        run_root: Path,
        metrics_publisher: MetricsService,
    ) -> TrainingConfig:
        trainer = self._training.create_trainer(
            manifest=result.manifest,
            local_public_key=local_public_key,
        )
        return TrainingConfig(
            algorithm=build_algorithm(
                manifest=result.manifest,
                trainer=trainer,
            ),
            load_checkpoint=trainer.load_checkpoint,
            run_store=RunStore(run_root / "run-store"),
            artifact_root=run_root / "rounds",
            metrics_publisher=metrics_publisher,
        )


def prepare_cifar_training(
    *,
    draft: DraftRunSpec,
    dataset_cache: Path,
    benchmark_seed: int,
    device: str = "cpu",
) -> PreparedCIFARTraining:
    """Prepare local data through the deep training-owned interface."""
    return PreparedCIFARTraining(
        _training=prepare_training(
            draft=draft,
            cache_dir=dataset_cache,
            benchmark_seed=benchmark_seed,
            device=device,
        )
    )


@dataclass(frozen=True, slots=True)
class PreparedLocalTraining:
    """Compose a validated node-local workload with runtime durability."""

    _training: TrainingOwnedLocal

    @property
    def tensor_schema(self) -> TensorSchema:
        return self._training.tensor_schema

    def validate_draft(self, draft: DraftRunSpec) -> None:
        self._training.validate_draft(draft)

    def create_initial_checkpoint(self, path: Path) -> InitialCheckpoint:
        return self._training.create_initial_checkpoint(path)

    def build_config(
        self,
        *,
        result: FormationResult,
        local_public_key: str,
        run_root: Path,
        metrics_publisher: MetricsService | None = None,
        evaluation_interval: int = 1,
    ) -> TrainingConfig:
        trainer = self._training.create_trainer(
            manifest=result.manifest, local_public_key=local_public_key
        )
        return TrainingConfig(
            algorithm=build_algorithm(manifest=result.manifest, trainer=trainer),
            load_checkpoint=trainer.load_checkpoint,
            run_store=RunStore(run_root / "run-store"),
            artifact_root=run_root / "rounds",
            metrics_publisher=metrics_publisher,
            evaluation_interval=evaluation_interval,
        )


def prepare_local_training(
    *,
    draft: DraftRunSpec,
    data: LocalClassificationData,
    model: nn.Module,
    model_definition: str,
    seed: int,
    device: str = "cpu",
) -> PreparedLocalTraining:
    """Validate independent local data before the runtime enters formation."""
    return PreparedLocalTraining(
        prepare_training_local(
            draft=draft, data=data, model=model, model_definition=model_definition,
            seed=seed, device=device,
        )
    )


def prepare_local_file_training(
    *, draft: DraftRunSpec, binding_path: Path, seed: int, device: str = "cpu"
) -> PreparedLocalTraining:
    """Prepare a local NPZ binding using a built-in model recipe."""
    recipe = resolve_model(draft.model_id, definition_hash=draft.model_definition_hash)
    return prepare_local_training(
        draft=draft,
        data=load_local_data(binding_path),
        model=recipe.build(seed=seed),
        model_definition=recipe.definition,
        seed=seed,
        device=device,
    )


type LocalTrainingFactory = Callable[[DraftRunSpec], PreparedLocalTraining]


def build_algorithm(
    *, manifest: SealedManifest, trainer: WeightTrainer
) -> GossipAlgorithm:
    """Construct the manifest-selected algorithm behind one runtime seam."""
    if manifest.algorithm_id == DPSGD_ALGORITHM_ID:
        return DPSGDAdapter(
            trainer=trainer,
            tensor_schema=manifest.tensor_schema,
            local_steps=manifest.local_steps,
            training_round_count=manifest.round_count,
            manifest_codec_id=manifest.codec_id,
        )
    if manifest.algorithm_id != NOLOCO_ALGORITHM_ID:
        raise ValueError("unsupported runtime algorithm")
    config = manifest.algorithm_config
    codec_settings = manifest.artifact_codecs
    if config is None or codec_settings is None:
        raise ValueError("NoLoCo manifest configuration is incomplete")
    settings = {setting.artifact_name: setting for setting in codec_settings}
    codec_ids = {name: setting.codec_id for name, setting in settings.items()}
    outer_setting = settings["outer_gradient"]
    if outer_setting.codec_id == "identity-v1":
        artifact_codecs = {
            "outer_gradient": IdentityCodec("identity-v1"),
            "slow_weights": IdentityCodec("identity-v1"),
        }
    elif outer_setting.codec_id == "topk-int8-v1":
        if outer_setting.top_k_fraction is None:
            raise ValueError("compressed outer gradient requires top-k fraction")
        artifact_codecs = {
            "outer_gradient": TopKInt8Codec(
                manifest.tensor_schema,
                top_k_fraction=outer_setting.top_k_fraction,
            ),
            "slow_weights": DenseInt8Codec(manifest.tensor_schema),
        }
    else:
        if outer_setting.top_k_fraction is None:
            raise ValueError("compressed outer gradient requires top-k fraction")
        artifact_codecs = {
            "outer_gradient": BitmapTopKInt8Codec(
                manifest.tensor_schema,
                top_k_fraction=outer_setting.top_k_fraction,
            ),
            "slow_weights": DenseInt8Codec(manifest.tensor_schema),
        }
    return NoLoCoAlgorithm(
        trainer=trainer,
        tensor_schema=manifest.tensor_schema,
        config=config,
        artifact_codecs=artifact_codecs,
        manifest_codec_ids=codec_ids,
    )


class NodeRuntime:
    """Own formation and post-formation training lifecycle."""

    def __init__(
        self,
        *,
        transport: AsyncTransport,
        draft: DraftRunSpec,
        environment: EnvironmentFingerprint,
        dataset: DataContract,
        artifact_root: Path,
        event_sink: EventSink | None = None,
        training: TrainingConfig | None = None,
        failure: FailureConfig | None = None,
        local_tensor_schema: TensorSchema | None = None,
    ) -> None:
        self._transport = transport
        self._formation = FormationProtocol(
            transport=transport,
            draft=draft,
            environment=environment,
            dataset=dataset,
            transport_limits=draft.transport,
            artifact_root=artifact_root,
            event_sink=event_sink,
            local_tensor_schema=local_tensor_schema,
        )
        self._state = NodeState.CREATED
        self._result: FormationResult | None = None
        self._training = training
        self._failure = failure
        self._engine: GossipEngine | None = None
        self._consensus_telemetry: LiveConsensusTelemetry | None = None
        self._event_sink = event_sink
        self._local_public_key: str | None = None
        self._commits: tuple[RoundCommit, ...] = ()
        self._run_task: asyncio.Task[tuple[RoundCommit, ...]] | None = None
        self._control_task: asyncio.Task[None] | None = None
        self._remote_failure: PeerRunFailureError | None = None
        self._terminal_lock = asyncio.Lock()

    @property
    def state(self) -> NodeState:
        return self._state

    @property
    def formation_result(self) -> FormationResult:
        if self._result is None:
            raise NodeRuntimeError("node has not completed formation")
        return self._result

    @property
    def training_commits(self) -> tuple[RoundCommit, ...]:
        return self._commits

    def configure_training(self, training: TrainingConfig) -> None:
        """Attach the local trainer once fixed membership has formed."""
        if self._state is not NodeState.READY:
            raise NodeRuntimeError(f"cannot configure training from {self._state}")
        if self._training is not None:
            raise NodeRuntimeError("training is already configured")
        self._training = training

    async def run_to_completion(
        self,
        *,
        formation: FormationRequest,
        training_factory: TrainingFactory,
        manifest_expectation: SealedManifestExpectation | None = None,
        ready_hook: ReadyHook | None = None,
        completion_hook: CompletionHook | None = None,
    ) -> NodeRunResult:
        """Own formation, validation, training, hooks, and cleanup ordering."""
        if self._failure is None:
            raise NodeRuntimeError(
                "run-to-completion requires pre-run failure persistence"
            )
        if self._training is not None:
            raise NodeRuntimeError(
                "run-to-completion owns post-formation training construction"
            )
        try:
            if isinstance(formation, InitiatorFormation):
                result = await self.initiate(
                    bootstrap_uri=formation.bootstrap_uri,
                    checkpoint_path=formation.checkpoint_path,
                    tensor_schema=formation.tensor_schema,
                )
            else:
                result = await self.join(invitation=formation.invitation)

            try:
                if manifest_expectation is not None:
                    validate_sealed_expectation(manifest_expectation, result.manifest)
                training = await asyncio.to_thread(training_factory, result)
                self.configure_training(training)
                if ready_hook is not None:
                    hook_result = ready_hook(result)
                    if inspect.isawaitable(hook_result):
                        await hook_result
            except BaseException as error:
                await self.fail_before_run(error)
                raise

            commits = await self.run()
            terminal = NodeRunResult(formation=result, commits=commits)
            if completion_hook is not None:
                hook_result = completion_hook(terminal)
                if inspect.isawaitable(hook_result):
                    await hook_result
            return terminal
        finally:
            await self.stop()

    async def fail_before_run(self, error: BaseException) -> None:
        """Persist and announce a formed node failure before training starts."""
        assert self._result is not None
        run_store, _ = self._failure_dependencies()
        persistence_error: Exception | None = None
        try:
            async with self._terminal_lock:
                if self._state is not NodeState.READY:
                    raise NodeRuntimeError(
                        f"cannot fail node before run from {self._state}"
                    )
                self._state = NodeState.FAILED
                try:
                    await asyncio.to_thread(run_store.initialize, self._result.manifest)
                    await asyncio.to_thread(
                        run_store.record_terminal,
                        "failed",
                        {
                            "error_type": type(error).__name__,
                            "error": str(error)[:1024],
                        },
                    )
                except Exception as failure:
                    persistence_error = failure
            try:
                local_key = await self._transport.local_public_key()
                self._local_public_key = local_key
                failure_broadcaster = self._create_failure_broadcaster(local_key)
                await failure_broadcaster.broadcast_run_failed(
                    RunFailure(
                        round_id=0,
                        error_type=type(error).__name__,
                        reason=str(error)[:1024] or "node failed before training",
                    )
                )
            except Exception:
                pass
            try:
                if self._local_public_key is not None:
                    await asyncio.to_thread(
                        append_evidence,
                        self._event_sink,
                        RunFailedEvidence(
                            run_id=self._result.manifest.run_id,
                            manifest_hash=self._result.manifest_hash,
                            node_id=self._local_public_key,
                            message_id="run-failed-0",
                            round_id=0,
                            error_type=type(error).__name__,
                            error=(str(error)[:1024] or "node failed before training"),
                        ),
                    )
            except Exception:
                pass
        finally:
            await self._cleanup()
        if persistence_error is not None:
            raise persistence_error

    async def initiate(
        self,
        *,
        bootstrap_uri: str,
        checkpoint_path: Path,
        tensor_schema: TensorSchema,
    ) -> FormationResult:
        """Form as initiator using a checkpoint prepared by the local trainer."""
        await self._start_formation()
        try:
            result = await self._formation.initiate(
                bootstrap_uri=bootstrap_uri,
                checkpoint_path=checkpoint_path,
                tensor_schema=tensor_schema,
            )
        except BaseException:
            await self._fail()
            raise
        return self._ready(result)

    async def join(self, *, invitation: Invitation) -> FormationResult:
        await self._start_formation()
        try:
            result = await self._formation.join(invitation=invitation)
        except BaseException:
            await self._fail()
            raise
        return self._ready(result)

    async def run(self) -> tuple[RoundCommit, ...]:
        """Load formed checkpoint, run gossip rounds, and persist terminal state."""
        async with self._terminal_lock:
            if self._state is not NodeState.READY:
                raise NodeRuntimeError(f"cannot run node from {self._state}")
            if self._training is None:
                raise NodeRuntimeError("training is not configured")
            assert self._result is not None
            self._state = NodeState.RUNNING
        run_task = asyncio.current_task()
        assert run_task is not None
        self._run_task = run_task
        initialized = False
        try:
            await asyncio.to_thread(
                self._training.run_store.initialize, self._result.manifest
            )
            initialized = True
            await asyncio.to_thread(
                self._training.load_checkpoint, self._result.checkpoint_path
            )
            local_key = await self._transport.local_public_key()
            self._local_public_key = local_key
            self._training.algorithm.configure_bundle_codec(
                artifact_root=self._training.artifact_root / "bundles",
                run_id=self._result.manifest.run_id,
                manifest_hash=self._result.manifest_hash,
                sender_public_key=local_key,
                algorithm_id=self._result.manifest.algorithm_id,
            )
            participants = frozenset(
                participant.public_key
                for participant in self._result.manifest.participants
            )
            services = self._formation.services
            pair_transport = await self._create_pair_transport(
                local_key,
                metadata_root=self._training.artifact_root / "bundle-metadata",
            )
            formed_result = self._result
            assert formed_result is not None

            async def receive_consensus_sketch(
                timeout_seconds: float,
            ) -> ConsensusSketchMessage:
                envelope = await services.receiver.receive(
                    MessageChannel.TELEMETRY,
                    timeout_seconds=timeout_seconds,
                )
                if (
                    envelope.message_type is not MessageType.CONSENSUS_SKETCH
                    or envelope.round_id is None
                ):
                    raise ValueError("received invalid consensus sketch envelope")
                return ConsensusSketchMessage(
                    sender_public_key=envelope.sender_public_key,
                    round_id=envelope.round_id,
                    payload=envelope.payload,
                )

            async def publish_consensus_sketch(
                round_id: int, sketch: np.ndarray
            ) -> None:
                broadcast = await pair_transport.broadcast_consensus_sketch(
                    round_id=round_id,
                    sketch=sketch,
                )
                append_evidence(
                    self._event_sink,
                    ConsensusSketchSentEvidence(
                        run_id=formed_result.manifest.run_id,
                        manifest_hash=formed_result.manifest_hash,
                        node_id=local_key,
                        message_id=(
                            f"consensus-sketch-metric-{local_key[:8]}-{round_id}"
                        ),
                        round_id=round_id,
                        payload_bytes=broadcast.payload_bytes,
                        recipient_count=broadcast.recipient_count,
                        successful_recipient_count=(
                            broadcast.successful_recipient_count
                        ),
                        retry_count=broadcast.retry_count,
                    ),
                )

            self._consensus_telemetry = LiveConsensusTelemetry(
                local_public_key=local_key,
                participant_keys=tuple(sorted(participants)),
                seed=self._result.manifest.consensus_sketch.seed,
                receive=receive_consensus_sketch,
                publish=publish_consensus_sketch,
                on_distance=self._record_consensus,
                size=self._result.manifest.consensus_sketch.size,
            )
            policy = self._result.manifest.training
            final_consensus_rounds = (
                policy.final_consensus_rounds if policy is not None else 0
            )
            self._engine = GossipEngine(
                local_public_key=local_key,
                round_count=(
                    self._result.manifest.round_count + final_consensus_rounds
                ),
                scheduler=PeerScheduler(
                    self._result.manifest.participants,
                    seed=self._result.manifest.peer_scheduler_seed,
                    training_round_count=self._result.manifest.round_count,
                    final_consensus_rounds=final_consensus_rounds,
                ),
                algorithm=self._training.algorithm,
                transport=pair_transport,
                commit_callback=self._prepare_commit,
                confirm_callback=self._confirm_commit,
                transport_limits=self._result.manifest.transport,
                failure_broadcaster=pair_transport,
                consensus_publisher=self._consensus_telemetry,
                evaluation_interval=self._training.evaluation_interval,
                metrics_publisher=self._training.metrics_publisher,
            )
            await self._start_metrics()
            await self._consensus_telemetry.start()
            commits = await self._engine.run()
            async with self._terminal_lock:
                if self._remote_failure is not None:
                    raise self._remote_failure
                write_task = asyncio.create_task(
                    asyncio.to_thread(
                        self._training.run_store.record_terminal,
                        "complete",
                        {"committed_rounds": len(commits)},
                    )
                )
                try:
                    await asyncio.shield(write_task)
                except asyncio.CancelledError:
                    await write_task
                self._commits = commits
                self._state = NodeState.COMPLETE
            return commits
        except asyncio.CancelledError as error:
            self._state = NodeState.FAILED
            failure = self._remote_failure or error
            await self._record_terminal_failure(
                initialized, result="failed", error=failure
            )
            if self._remote_failure is not None:
                raise self._remote_failure from error
            raise
        except Exception as error:
            self._state = NodeState.FAILED
            await self._record_terminal_failure(
                initialized, result="failed", error=error
            )
            raise
        finally:
            if self._run_task is run_task:
                self._run_task = None
            await self._cleanup()

    async def stop(self) -> None:
        if self._state is NodeState.STOPPED:
            return
        task = self._run_task
        if (
            self._state is NodeState.RUNNING
            and task is not None
            and task is not asyncio.current_task()
        ):
            task.cancel()
            try:
                await task
            except BaseException:
                pass
        await self._stop_control_monitor()
        if self._state is not NodeState.CREATED:
            await self._formation.stop()
        self._state = NodeState.STOPPED

    async def _start_formation(self) -> None:
        if self._state is not NodeState.CREATED:
            raise NodeRuntimeError(f"cannot form node from {self._state}")
        self._state = NodeState.FORMING
        try:
            await self._formation.start()
        except BaseException:
            self._state = NodeState.FAILED
            raise

    async def _fail(self) -> None:
        self._state = NodeState.FAILED
        await self._formation.stop()

    async def _start_metrics(self) -> None:
        if self._training is not None and self._training.metrics_publisher is not None:
            await self._training.metrics_publisher.start()

    async def _create_pair_transport(
        self, local_key: str, *, metadata_root: Path
    ) -> AXLPairTransport:
        assert self._result is not None
        participants = frozenset(
            participant.public_key for participant in self._result.manifest.participants
        )
        services = self._formation.services
        return await asyncio.to_thread(
            AXLPairTransport,
            local_public_key=local_key,
            run_id=self._result.manifest.run_id,
            manifest_hash=self._result.manifest_hash,
            algorithm_id=self._result.manifest.algorithm_id,
            transport_limits=self._result.manifest.transport,
            receiver=services.receiver,
            sender=services.sender,
            transfer_manager=services.transfer_manager,
            metadata_root=metadata_root,
            participant_keys=participants,
        )

    def _create_failure_broadcaster(self, local_key: str) -> AXLFailureBroadcaster:
        assert self._result is not None
        participants = frozenset(
            participant.public_key for participant in self._result.manifest.participants
        )
        return AXLFailureBroadcaster(
            local_public_key=local_key,
            run_id=self._result.manifest.run_id,
            manifest_hash=self._result.manifest_hash,
            algorithm_id=self._result.manifest.algorithm_id,
            transport_limits=self._result.manifest.transport,
            sender=self._formation.services.sender,
            participant_keys=participants,
        )

    def _failure_dependencies(self) -> tuple[RunStore, Path]:
        if self._training is not None:
            return self._training.run_store, self._training.artifact_root
        if self._failure is not None:
            return self._failure.run_store, self._failure.artifact_root
        raise NodeRuntimeError("failure persistence is not configured")

    async def _monitor_run_failures(self) -> None:
        services = self._formation.services
        while self._state in {NodeState.READY, NodeState.RUNNING}:
            try:
                envelope = await services.receiver.receive(
                    MessageChannel.CONTROL,
                    timeout_seconds=0.1,
                )
            except TimeoutError:
                continue
            if envelope.message_type is not MessageType.RUN_FAILED:
                continue
            try:
                failure = decode_run_failure(envelope.payload)
            except ValueError:
                continue
            error = PeerRunFailureError(
                f"peer {envelope.sender_public_key} failed at round "
                f"{failure.round_id}: {failure.error_type}: {failure.reason}"
            )
            async with self._terminal_lock:
                if self._state not in {NodeState.READY, NodeState.RUNNING}:
                    return
                self._remote_failure = error
                task = self._run_task
                if self._state is NodeState.RUNNING and task is not None:
                    task.cancel()
                    return
                self._state = NodeState.FAILED
                try:
                    run_store, _ = self._failure_dependencies()
                    assert self._result is not None
                    await asyncio.to_thread(run_store.initialize, self._result.manifest)
                    await asyncio.to_thread(
                        run_store.record_terminal,
                        "failed",
                        {
                            "error_type": type(error).__name__,
                            "error": str(error)[:1024],
                        },
                    )
                finally:
                    await self._cleanup()
            return

    async def _stop_control_monitor(self) -> None:
        task = self._control_task
        if task is None:
            return
        self._control_task = None
        if task is asyncio.current_task():
            return
        task.cancel()
        try:
            await task
        except BaseException:
            pass

    async def _stop_metrics(self) -> None:
        if self._training is not None and self._training.metrics_publisher is not None:
            await self._training.metrics_publisher.stop()

    async def _stop_consensus(self) -> None:
        telemetry = self._consensus_telemetry
        if telemetry is None:
            return
        await telemetry.stop()
        if telemetry.dropped and self._result is not None:
            await asyncio.to_thread(
                emit_event,
                "consensus_telemetry_dropped",
                run_id=self._result.manifest.run_id,
                manifest_hash=self._result.manifest_hash,
                node_id=self._local_public_key,
                message_id="consensus-telemetry-dropped",
                dropped=telemetry.dropped,
                sink=self._event_sink,
            )

    async def _record_terminal_failure(
        self, initialized: bool, *, result: str, error: BaseException
    ) -> None:
        if not initialized or self._training is None:
            return
        async with self._terminal_lock:
            try:
                await asyncio.to_thread(
                    self._training.run_store.record_terminal,
                    result,
                    {
                        "error_type": type(error).__name__,
                        "error": str(error)[:1024],
                    },
                )
            except Exception:
                pass

    async def _cleanup(self) -> None:
        for cleanup in (
            self._stop_control_monitor,
            self._stop_consensus,
            self._stop_metrics,
            self._formation.stop,
        ):
            try:
                await cleanup()
            except BaseException:
                pass

    async def _record_consensus(self, distance: ConsensusDistance) -> None:
        if (
            self._training is None
            or self._result is None
            or self._local_public_key is None
        ):
            return
        await asyncio.to_thread(
            self._training.run_store.record_consensus,
            round_id=distance.round_id,
            normalized_rms=distance.normalized_rms,
            sketch_count=distance.sketch_count,
        )
        await asyncio.to_thread(
            append_evidence,
            self._event_sink,
            ConsensusDistanceEvidence(
                run_id=self._result.manifest.run_id,
                manifest_hash=self._result.manifest_hash,
                node_id=self._local_public_key,
                message_id=f"consensus-distance-{distance.round_id}",
                round_id=distance.round_id,
                normalized_rms=float(distance.normalized_rms),
                sketch_count=distance.sketch_count,
            ),
        )

    def _prepare_commit(self, commit: RoundCommit) -> None:
        assert self._training is not None
        metrics: dict[str, object] = {"round_id": commit.round_id}
        if commit.local_loss is not None:
            metrics["local_loss"] = commit.local_loss
        if commit.error_feedback_residual_l2_norm is not None:
            metrics["error_feedback_residual_l2_norm"] = (
                commit.error_feedback_residual_l2_norm
            )
        if commit.error_feedback_signal_l2_norm is not None:
            metrics["error_feedback_signal_l2_norm"] = (
                commit.error_feedback_signal_l2_norm
            )
        if commit.error_feedback_residual_to_signal_ratio is not None:
            metrics["error_feedback_residual_to_signal_ratio"] = (
                commit.error_feedback_residual_to_signal_ratio
            )
        self._training.run_store.persist_prepared_commit(
            committed_round=commit.round_id,
            algorithm_state=self._training.algorithm.checkpoint_tensors(),
            state_checksum=commit.state_checksum,
            schedule={
                "round_id": commit.round_id,
                "peer": commit.peer_public_key,
                "phase": commit.phase,
            },
            metrics=metrics,
            transfer_diagnostics={
                "transfer_id": commit.transfer_id,
                "retries": commit.transfer_retries,
            },
        )

    def _confirm_commit(self, commit: RoundCommit) -> None:
        assert self._training is not None
        self._training.run_store.confirm_prepared_commit(
            committed_round=commit.round_id,
            state_checksum=commit.state_checksum,
        )

    def _ready(self, result: FormationResult) -> FormationResult:
        self._result = result
        self._state = NodeState.READY
        self._control_task = asyncio.create_task(
            self._monitor_run_failures(),
            name="dromeus-control-monitor",
        )
        return result
